package com.inesa.sensordb.api;

/**
 * Created by pc on 15-5-13.
 */
public class ItemWithoutValue {
    public String sensorID;
    public long timestamp;
    public double x;
    public double y;
    public double z;
}